#include "macrostate.h"

MacroState::MacroState(QObject *parent) :
    QStateMachine(parent)
{
}
