/****************************************************************************
**
** Copyright (C) 2013 Digia Plc and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Digia Plc and its Subsidiary(-ies) nor the names
**     of its contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef DESIGNWINDOW_H
#define DESIGNWINDOW_H

#include "diagramitem.h"
#include "arrow.h"
#include "enumclasses.h"

//#include <QMainWindow>
#include <QWidget>

class DiagramScene;

QT_BEGIN_NAMESPACE
class QAction;
class QToolBox;
class QSpinBox;
class QComboBox;
class QFontComboBox;
class QButtonGroup;
class QLineEdit;
class QGraphicsTextItem;
class QFont;
class QToolButton;
class QToolBar;
class QAbstractButton;
class QGraphicsView;
class AsLazyNutObject;
class ObjectCatalogue;
//typedef QHash<QString,LazyNutObject*> LazyNutObjectCatalogue;
QT_END_NAMESPACE

//! [0]
class DesignWindow : public QWidget
{
    Q_OBJECT

public:
   DesignWindow(ObjectCatalogue *objectCatalogue, QString boxType, QString arrowType, QWidget *parent = 0);
   void setObjCatalogue(ObjectCatalogue *catalogue);
   void prepareToLoadLayout(QString fileName);

public slots:
   void updateDiagramScene();

signals:
//    void showObj(LazyNutObj * obj, LazyNutObjCatalogue* objHash);
    void objectSelected(QString);
    void savedLayoutToBeLoaded(QString);
    void saveLayout();
    void layoutSaveAttempted();

private slots:
    void dispatchObjectSelected(QString name);
//    void backgroundButtonGroupClicked(QAbstractButton *button);
//    void connectionButtonGroupClicked(int id);
//    void layerButtonGroupClicked(int id);
    void deleteItem();
//    void pointerGroupClicked(int id);
//    void bringToFront();
//    void sendToBack();
//    void itemInserted(DiagramItem *item);
//    void textInserted(QGraphicsTextItem *item);
//    void currentFontChanged(const QFont &font);
//    void fontSizeChanged(const QString &size);
    void sceneScaleChanged(const QString &scale);
//    void textColorChanged();
//    void itemColorChanged();
//    void lineColorChanged();
//    void textButtonTriggered();
//    void fillButtonTriggered();
//    void lineButtonTriggered();
//    void handleFontChange();
//    void itemSelected(QGraphicsItem *item);
//    void about();

private:
//    void createToolBox();
//    void createActions();
    void createMenus();
    void createToolbars();
    void createTestDiagram();

//    QWidget *createBackgroundCellWidget(const QString &text,
//                                        const QString &image);
//    QWidget *createCellWidget(const QString &text,
//                              DiagramItem::DiagramType type);
//    QWidget *createConnectionCellWidget(const QString &text,
//                                        const QString &image, Arrow::ArrowTipType type);
//    QMenu *createColorMenu(const char *slot, QColor defaultColor);
//    QIcon createColorToolButtonIcon(const QString &image, QColor color);
//    QIcon createColorIcon(QColor color);

    DiagramScene *scene;
    QGraphicsView *view;
    ObjectCatalogue *objectCatalogue;
    QString curJson;
    QString boxType;

//    QAction *exitAction;
//    QAction *addAction;
//    QAction *deleteAction;

//    QAction *toFrontAction;
//    QAction *sendBackAction;
//    QAction *aboutAction;

//    QMenu *fileMenu;
    QMenu *itemMenu;
//    QMenu *aboutMenu;

//    QToolBar *textToolBar;
//    QToolBar *editToolBar;
//    QToolBar *colorToolBar;
    QToolBar *pointerToolbar;

    QComboBox *sceneScaleCombo;
//    QComboBox *itemColorCombo;
//    QComboBox *textColorCombo;
//    QComboBox *fontSizeCombo;
//    QFontComboBox *fontCombo;

//    QToolBox *toolBox;
//    QButtonGroup *layerButtonGroup;
//    QButtonGroup *pointerTypeGroup;
//    QButtonGroup *backgroundButtonGroup;
//    QButtonGroup *connectionButtonGroup;
//    QToolButton *fontColorToolButton;
//    QToolButton *fillColorToolButton;
//    QToolButton *lineColorToolButton;
//    QAction *boldAction;
//    QAction *underlineAction;
//    QAction *italicAction;
//    QAction *textAction;
//    QAction *fillAction;
//    QAction *lineAction;
};
//! [0]

#endif // DESIGNWINDOW_H
