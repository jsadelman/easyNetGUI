lazyNutGUI
==========

GUI for lazyNut
