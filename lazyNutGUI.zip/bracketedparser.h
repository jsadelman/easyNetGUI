#ifndef BRACKETEDPARSER_H
#define BRACKETEDPARSER_H

#include <QStringList>

class BracketedParser
{
public:
    static QStringList parse(QString text);
};

#endif // BRACKETEDPARSER_H
